show databases;
use negocioWebRopa;
call SP_Tables;
call SP_Procedures;
call SP_Constraints;
call SP_Indexs;
call SP_Triggers;
call SP_Views;

drop view V_total;

create view V_total as
	select c.id idCliente ,concat(c.apellido,' ',c.nombre) nombre, fenaci fecha_nacimiento, TIMESTAMPDIFF(YEAR,fenaci,CURDATE()) edad, c.direccion, c.email, c.telefono, 
		c.tipoDocumento, c.numeroDocumento, f.letra , f.numero , f.fecha, f.medioDePago, 
		(select sum(precio*cantidad) from detalles where idFactura=f.id) monto,
		d.precio precioVenta, d.cantidad , a.id idArticulo, a.descripcion, a.color, a.precio, a.talle_num, a.temporada,
		a.tipo, a.stock, a.stockMin, a.stockMax 
		from clientes c join facturas f on c.id=f.idCliente 
		join detalles d on f.id=d.idFactura 
		join articulos a on d.idArticulo=a.id;
        
select * from V_total;
select * from clientes;
select * from articulos;
select * from facturas;
select * from detalles;

insert into facturas (letra,numero,fecha,medioDePago,idCliente) values
('A',1,curdate(),'EFECTIVO',1);

insert into detalles (idArticulo,idFactura,precio,cantidad) values
(1,1,100,2),
(2,1,200,1);

select count(*) cantidad from clientes;				--  6
select count(*) cantidad from facturas;				--  1
select count(*) cantidad from detalles;				--  2
select count(*) cantidad from articulos;			-- 10
select 6 * 1 * 2 * 10;

describe clientes;

delimiter //
create procedure SP_Clientes_Insert_Min (in Pnombre varchar(20), Papellido varchar(20))
begin
	insert into clientes (nombre,apellido) values (Pnombre,Papellido);
end
// delimiter ;

drop procedure if exists SP_Clientes_Insert_Full;

delimiter //
create procedure SP_Clientes_Insert_Full (in Pnombre varchar(20), Papellido varchar(20),
		Pfenaci date, Pdireccion varchar(50), Pemail varchar(30), 
        Ptelefono  varchar(25), PtipoDocumento varchar(20), PnumeroDocumento char(8))
begin
	insert into clientes 
		(nombre,apellido,fenaci,direccion,email,telefono,tipoDocumento,numeroDocumento) 
        values 
        (Pnombre,Papellido,Pfenaci,Pdireccion,Pemail,Ptelefono,PtipoDocumento,PnumeroDocumento);
end
// delimiter ;

delimiter //
create procedure SP_Clientes_Delete (in Pid int)
begin
	delete from clientes where id=Pid;
end
// delimiter ;

drop procedure if exists SP_Clientes_Update;

delimiter //
create procedure SP_Clientes_Update (in Pid int, Pnombre varchar(20), Papellido varchar(20),
		Pfenaci date, Pdireccion varchar(50), Pemail varchar(30), 
        Ptelefono  varchar(25), PtipoDocumento varchar(20), PnumeroDocumento char(8))
begin
	update clientes set nombre=Pnombre, apellido=Papellido, fenaci=Pfenaci, direccion=Pdireccion,
					email=Pemail, telefono=Ptelefono, tipoDocumento=PtipoDocumento,
					numeroDocumento=PnumeroDocumento where id=Pid;
end
// delimiter ;

delimiter //
create procedure SP_Clientes_All ()
begin
	select id idCliente ,concat(apellido,' ',nombre) nombre, fenaci fecha_nacimiento, 
    TIMESTAMPDIFF(YEAR,fenaci,CURDATE()) edad, direccion, email, telefono,
    tipoDocumento, numeroDocumento from clientes;
end
// delimiter ;

call SP_Clientes_Insert_Min('Andrea','Moretti');
call SP_Clientes_Insert_Full('Marcelo','Gallardo','1976/12/12','Libertador 202','muñeco@gmail.com','1234565','DNI','86086001');
call SP_Clientes_Delete(3);
call SP_Clientes_Update(7,'Andrea','Moretti','1978/5/25','Laprida 2121','andy@gmail.com','12345678','DNI','03034560');
call SP_Clientes_All();
select * from clientes;

-- Modificación de BD 			10/05/2021
-- ELiminamos el campo edad en clientes y agregamos el campo fenaci en clientes.
alter table clientes drop edad;
alter table clientes add fenaci date after apellido;

update clientes set fenaci='1980/06/02' where id=1;
update clientes set fenaci='1992/10/12' where id=2;
update clientes set fenaci='1999/12/24' where id=4;
update clientes set fenaci='2005/06/02' where id=5;

-- calculo de edad o antiguedad
select datediff(curdate(),fenaci) from clientes;
select floor(datediff(curdate(),fenaci)/365) edad from clientes;
SELECT TIMESTAMPDIFF(YEAR,fenaci,CURDATE()) edad  FROM clientes;

create view V_clientes as
	select id idCliente ,concat(apellido,' ',nombre) nombre, fenaci fecha_nacimiento, 
    TIMESTAMPDIFF(YEAR,fenaci,CURDATE()) edad, direccion, email, telefono,
    tipoDocumento, numeroDocumento from clientes;

select * from V_clientes;

/*
	Trabajo 1
    
    Crear los siguientes store procedures para la base negocioWebRopa
    
    - Tabla articulos
		SP_Articulos_Insert_Min
        SP_Articulos_Insert_Full
        SP_Articulos_Delete
        SP_Articulos_Update
        SP_Articulos_All
        SP_Articulos_Reponer
        
	- Tabla facturas
		SP_Facturas_Insert
        SP_Facturas_Delete
        SP_Facturas_Update
		SP_Facturas_All
		SP_Facturas_AgregarDetalle
        
	- Tabla detalles
		SP_Detalles_Delete
		SP_Detalles_All

*/








