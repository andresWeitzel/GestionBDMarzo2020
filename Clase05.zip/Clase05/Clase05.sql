/*

	Lenguaje SQL
	
	DDL:	Data Definition Language	
			(Create, Alter, Drop)		
			(Objetos tablas, vistas, procedures etc)
			Baja compatibilidad con ANSI-SQL


	DML:	Data Manipulation Language
			(Insert, Delete, Update, Select)
			Operatoria de registros en tablas.
			Alta compatibilidad con ANSI-SQL
			
			
	DCL:	Data Control Language
			Transactions - Exceptions - Estructuras
			Baja compatibilidad con ANSI-SQL
			

*/

-- catalogo de tablas
SELECT
   *
FROM
   pg_catalog.pg_tables
WHERE
   schemaname != 'pg_catalog'
AND schemaname != 'information_schema';


-- describe clientes;
SELECT
   *
FROM
   information_schema.COLUMNS
WHERE
   TABLE_NAME = 'clientes';

/*
 * 
 * precio float;		(32 bits)
 * 
 * 		10000.50
 * 		--------
 * 
 *  precio double float8	(64 bits)
 * 
 * 		1000000000000.50
 * 		----------------
 */
  
  INSERT INTO cursos (titulo,profesor,dia,turno) VALUES
	 ('Java','Vasquez','MARTES','NOCHE'),
	 ('Cocina','Germani','JUEVES','TARDE'),
	 ('Java','Gomez','MARTES','TARDE'),
	 ('HTML','Sosa','LUNES','NOCHE'),
	 ('PHP','Dieguez','VIERNES','MAÑANA'),
	 ('PHP','Torres','JUEVES','NOCHE'),
	 ('Javascript','Vega','JUEVES','NOCHE'),
	 ('Jardineria','Trole','LUNES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA');
INSERT INTO cursos (titulo,profesor,dia,turno) VALUES
	 ('Python','Pedro','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA');
INSERT INTO cursos (titulo,profesor,dia,turno) VALUES
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('Jabones Artesanales','Lopez','MARTES','MAÑANA'),
	 ('PHP','Mendoza','MARTES','MAÑANA'),
	 ('Hibernate','Toloza','JUEVES','TARDE'),
	 ('Pintura Clasica','Orue','LUNES','TARDE'),
	 ('Hibernate','Toloza','JUEVES','TARDE'),
	 ('Hibernate','Toloza','JUEVES','TARDE'),
	 ('Hibernate','Toloza','JUEVES','TARDE'),
	 ('Hibernate','Toloza','JUEVES','TARDE');
INSERT INTO cursos (titulo,profesor,dia,turno) VALUES
	 ('Hibernate','Toloza','JUEVES','TARDE'),
	 ('Reposteria','Luciano','MARTES','TARDE'),
	 ('Cocina','Orue','LUNES','MAÑANA'),
	 ('JAVA','RIOS','JUEVES','NOCHE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE');
INSERT INTO cursos (titulo,profesor,dia,turno) VALUES
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE');
INSERT INTO cursos (titulo,profesor,dia,turno) VALUES
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('JavaScript','Vega','MARTES','TARDE'),
	 ('Hibernate','Toloza','JUEVES','TARDE'),
	 ('Hibernate','Toloza','JUEVES','TARDE'),
	 ('Hibernate','Toloza','JUEVES','TARDE'),
	 ('Java','Fermandez','MIERCOLES','TARDE');
INSERT INTO cursos (titulo,profesor,dia,turno) VALUES
	 ('Cocina','Germani','LUNES','MAÑANA'),
	 ('Hibernate','Toloza','JUEVES','TARDE');
	
INSERT INTO alumnos (nombre,apellido,edad,idCurso) VALUES
	 ('Jesica','Revoredo',32,1),
	 ('Fernando','Torresti',34,2),
	 ('Jeremias','Sprinfield',99,1),
	 ('Pedro','Perez',30,1),
	 ('Juan','Mendoza',40,1),
	 ('Victor','Perez',30,2),
	 ('Mariela','Perez',30,2),
	 ('Mercedez','Perez',30,3),
	 ('Carola','deMarchi',38,5),
	 ('Carola','deMarchi',38,2);
INSERT INTO alumnos (nombre,apellido,edad,idCurso) VALUES
	 ('Carola','deMarchi',38,2),
	 ('Carola','deMarchi',38,2),
	 ('Carola','deMarchi',38,2),
	 ('Carola','deMarchi',38,2),
	 ('Teodoro','Lopez',23,37),
	 ('Jose','Ledesma',34,3),
	 ('Gustavo','Jaen',38,5),
	 ('Gustavo','Jaen',38,1),
	 ('Gustavo','Jaen',38,1),
	 ('Gustavo','Jaen',38,1);
INSERT INTO alumnos (nombre,apellido,edad,idCurso) VALUES
	 ('Gustavo','Jaen',38,1),
	 ('Gustavo','Jaen',38,1),
	 ('Gustavo','Jaen',38,1),
	 ('Gustavo','Jaen',38,1),
	 ('Carola','deMarchi',38,2),
	 ('Carola','deMarchi',38,2),
	 ('Carola','deMarchi',38,2),
	 ('Carola','deMarchi',38,2);
  
  
