
-- Tienda de ropa
drop database if exists ropa;
create database ropa;
use ropa;

/*
 * factura ropa 
 * la camisa
 * las sandalias
 * talle
 * producto
 * precio
 * color
 * clientes
 * marca
 * numero de articulo
 * stock
 */

-- cliente
-- 			id
-- 			nombre
-- 			apellido
-- 			edad
-- 			direccion
-- 			email
-- 			telefono
-- 			tipoDocumento	enum('DNI','LIBRETA_CIVICA','LIBRETA_ENROLAMIENTO','PASS')
-- 			numeroDocumento

-- facturas
-- 			id
-- 			letra enum('A','B','C')
-- 			numero
-- 			fecha
-- 			medioDePago enum('EFECTIVO','DEBITO','TARJETA')
-- 			idCliente

-- detalles
-- 			id
-- 			idArticulo
-- 			idFactura
-- 			precio
-- 			cantidad

-- articulos
-- 			id
-- 			descripción
-- 			tipo		enum('CALZADO','ROPA')
-- 			color
-- 			talle_num
-- 			stock
-- 			precio
-- 			temporada enum('VERANO','OTOÑO','INVIERNO')

show databases;

show tables;


-- catalogo de tablas
select * from information_schema.TABLES where TABLE_SCHEMA = 'ropa';

-- catalogo de restricciones
select * from information_schema.TABLE_CONSTRAINTS where TABLE_SCHEMA ='ropa';

-- catalogo de vistas
select * from information_schema.VIEWS;


drop table if exists clientes;
drop table if exists faturas;
create table clientes(
	id int auto_increment primary key,
	nombre varchar(20) not null,
	apellido varchar(20) not null,
	edad int,
	direccion varchar(50),
	email varchar(30),
	telefono varchar(25),
	tipoDocumento enum('DNI','LIBRETA_CIVICA','LIBRETA_ENROLAMIENTO','PASS'),
	numeroDocumento char(8)
);

alter table clientes 
	add constraint CK_clientes_edad
    check (edad>=18 and edad<=120); 

alter table clientes
	add constraint U_clientes_TipoNumero
	unique(tipoDocumento,numeroDocumento);

create table facturas(
	id int auto_increment primary key,
	letra enum('A','B','C'),
	numero int,
    fecha date default(curdate()),
	medioDePago enum('EFECTIVO','DEBITO','TARJETA'),
 	idCliente int not null
);

-- creamos la restriccion FK facturas idCliente
alter table facturas
	add constraint FK_facturas_idCliente
    foreign key(idCliente)
    references clientes(id);

alter table facturas
	add constraint CK_facturas_numero
    check (numero>0);

/*
alter table facturas
	add constraint CK_facturas_fecha
	check (fecha >= (current_date()-5) and fecha<= current_date());
*/

alter table facturas 
	add constraint U_facturas_LetraNumero
    unique(letra,numero);

create table articulos(
	id int auto_increment primary key,
	descripcion varchar(25) not null,
	tipo enum('CALZADO','ROPA'),
	color varchar(20),
	talle_num varchar(20),
	stock int,
    stockMin int,
    stockMax int,
    costo double,
    precio double,
	temporada enum('VERANO','OTOÑO','INVIERNO')
);

insert into clientes (nombre,apellido) values ('Juan','Perez');
insert into facturas (letra,numero,medioDePago,idCliente) 
	values ('A',1,'EFECTIVO',1);

insert into facturas (letra,numero,medioDePago,idCliente,fecha)
	values ('A',2,'EFECTIVO',1,'2020-06-20');

select * from clientes;
select * from facturas;

truncate facturas;









