show databases;
use negocioWebRopa;
show tables;
call SP_Procedures;

drop procedure if exists SP_Functions;
delimiter //
	create procedure SP_Functions()
    begin
		select * from information_schema.routines 
			where ROUTINE_SCHEMA='negocioWebRopa' and ROUTINE_TYPE='FUNCTION';
    end
// delimiter ;

call SP_Functions();

drop function if exists F_Calcular_IVA;
delimiter //
	create function F_Calcular_IVA(monto double)
    returns double
    begin
		return round(monto*1.21,2);
    end;
// delimiter ;

select F_Calcular_IVA(300);
select * from articulos;
select *,F_Calcular_IVA(precio) precio_con_IVA from articulos;
select *,round(F_Calcular_IVA(precio),2) precio_con_IVA from articulos;
select id,descripcion,tipo,color,talle_num,stock,stockMin,stockMax,costo,precio,
	F_Calcular_IVA(precio) precio_con_IVA ,temporada from articulos;
    
select * from detalles;
select * from facturas;
select *,sum(precio*cantidad) monto from facturas f join detalles d on f.id=d.idFactura;
-- select id id,letra,numero,fecha,medioDePago,idCliente,
-- 	(select (precio*cantidad) from detalles d where d.idFactura=id) monto from facturas f;
    
drop function if exists F_Calcular_Monto;
delimiter //
	create function F_Calcular_Monto(PidFactura int)
    returns double
    begin
		return (select sum(precio*cantidad) from 
			facturas f join detalles d on f.id=d.idFactura
            where idFactura=PidFactura);
    end;
// delimiter ;

select *, F_Calcular_Monto(id) monto from facturas;

call SP_Functions;

-- Triggers
show tables;
select * from control;
call SP_Triggers;
delimiter //
create trigger TR_Clientes_Insert
	before insert on clientes
    for each row
    begin
		insert into control (tabla,accion) values ('clientes','insert');
    end;
// delimiter ;

delimiter //
create trigger TR_Clientes_Delete
	before delete on clientes
    for each row
    begin
		insert into control (tabla,accion) values ('clientes','delete');
    end;
// delimiter ;

select * from control;
select * from clientes;
insert into clientes (nombre,apellido) values 
	('Rodrigo','Pereyra'),
    ('Veronica','Conte');

call SP_Procedures;
call SP_Clientes_Insert_Min('Marita','Salinas');

set sql_safe_updates=0;
delete from clientes;
delete from clientes where id>10;

call SP_Triggers;
drop trigger if exists TR_Clientes_Insert;
drop trigger if exists TR_Clientes_Delete;

select * from control;
truncate control;
describe control;

delimiter //
create trigger TR_Clientes_Insert
	after insert on clientes
    for each row
    begin
		insert into control (tabla,accion,fecha,hora,usuario,idRegistro) 
        values ('clientes','insert',curdate(),curtime(),current_user(),NEW.id);
    end;
// delimiter ;

select * from clientes;







