show tables;

-- Procedimientos almacenados - stored procedure
select version();
select * from articulos;

/*
insert into articulos 
	(descripcion,tipo,color,talle_num,stock,stockMin,stockMax,costo,precio,temporada)
    values
    ('Remera','ROPA','rojo',1,5,20,10,10,8,'VERANO');
*/

LOCK TABLES `articulos` WRITE;
/*!40000 ALTER TABLE `articulos` DISABLE KEYS */;
INSERT INTO `articulos` VALUES 
(1,'Remera','ROPA','negro','large',15,10,50,100,120,'VERANO'),
(2,'Remera Lisa Jersey ','ROPA','azul','large',8,5,50,300,450,'OTOÑO'),
(3,'Chomba Pique ','ROPA','rojo','small',9,5,50,400,600,'OTOÑO'),
(4,'Musculosa Deportiva','ROPA','blanco','XXL',6,2,20,300,450,'VERANO'),
(5,'Remera Lisa Jersey','ROPA','negro','large',6,5,50,300,450,'OTOÑO'),
(6,'Remera Lisa Jersey','ROPA','negro','small',7,5,50,300,450,'OTOÑO'),
(7,'Chomba Pique','ROPA','azul','small',6,5,50,400,600,'OTOÑO'),
(8,'Remera Lisa Jersey','ROPA','rosa','XXL',7,5,50,300,450,'OTOÑO'),
(9,'Remera Lisa Jersey','ROPA','verde','small',7,5,50,300,450,'OTOÑO'),
(10,'Remera','ROPA','rojo','1',5,20,40,10,12,'VERANO');
/*!40000 ALTER TABLE `articulos` ENABLE KEYS */;
UNLOCK TABLES;

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES 
(1,'Fernando','Acme',34,'lima 222','intercrios@hotmail.com','23232312','DNI','12345678'),
(2,'Teofilo','GarciaLasca',43,'lima 222','lawlercarlospatricio@gmail.com','23232312','DNI','23567898'),
(3,'Coyote','Acme',34,'lima 222','c.rios@bue.edu.ar','23232312','DNI','12345679'),
(4,'Graciela','Meza',18,'lima 222','intercrios@hotmail.com','23232312','DNI','11111111'),
(5,'Juan ','Gomez',21,'medrano 165','gomez@gmail.com','33333333','DNI','88888888'),
(6,'Laura','Rojas',19,'medrano 165','rojas@gmail.com','77777777','DNI','77777777');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

select * from articulos;
select * from clientes;
describe articulos;
delimiter //
create procedure aumentar_precios()
begin
	update articulos set precio=precio*1.1 where temporada='OTOÑO';
end
// delimiter ;

-- consulta de catalogo
SELECT * FROM INFORMATION_SCHEMA.routines where routine_schema='negocioWebRopa';

select * from articulos;

-- desactivamos safe_updates
set sql_safe_updates=0;

-- ejecutar procedure
call aumentar_precios();

drop procedure if exists aumentar_precios2;

delimiter //
create procedure aumentar_precios2(in porcentaje int)
begin
	update articulos set precio=precio+precio*porcentaje/100;
end
// delimiter ;

call aumentar_precios2(20);

delimiter //
create procedure SP_aumentar(in porcentaje int, atemporada varchar(12))
begin
	update articulos set precio=round(precio+precio*porcentaje/100,2) where temporada=atemporada;
end
// delimiter ;

call SP_aumentar(20,'VERANO');
call SP_aumentar(20,'OTOÑO');

drop procedure aumentar_precios2;

delimiter //
	create procedure SP_Procedures()
    begin
		SELECT * FROM INFORMATION_SCHEMA.routines where routine_schema='negocioWebRopa';
    end
// delimiter ;

delimiter //
	create procedure SP_Constraints()
    begin
		select * from information_schema.TABLE_CONSTRAINTS where TABLE_SCHEMA ='negocioWebRopa';
    end
// delimiter ;

delimiter //
	create procedure SP_Tables()
    begin
		select * from information_schema.TABLES where TABLE_SCHEMA ='negocioWebRopa';
    end
// delimiter ;

delimiter //
	create procedure SP_Views()
    begin
		select * from information_schema.VIEWS where TABLE_SCHEMA ='negocioWebRopa';
    end
// delimiter ;

delimiter //
	create procedure SP_Indexs()
    begin
		select * from information_schema.STATISTICS where INDEX_SCHEMA ='negocioWebRopa';
    end
// delimiter ;

delimiter //
	create procedure SP_Triggers()
    begin
		select * from information_schema.TRIGGERS where TRIGGER_SCHEMA ='negocioWebRopa';
    end
// delimiter ;

drop procedure SP_Triggers;

call SP_Procedures();
call SP_Constraints();
call SP_Indexs();
call SP_Tables();
call SP_Views();
call SP_Triggers();

create table control(
	id int auto_increment primary key,
    tabla varchar(25) not null,
    accion enum('INSERT','DELETE','UPDATE'),
    fecha date,
    hora time,
    usuario varchar(25),
    idRegistro int
);